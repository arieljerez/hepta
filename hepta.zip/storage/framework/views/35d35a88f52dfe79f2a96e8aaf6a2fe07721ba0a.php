<?php $__env->startSection('content'); ?>
<div class="row">
      <div class="col-sm-10 col-sm-offset-1 col-md-10 col-md-offset-1">
        <div class="panel panel-default panel-info">
          <div class="panel-heading">Mis Datos</div>
          <div class="panel-body">

          </div>
        </div>
      </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>