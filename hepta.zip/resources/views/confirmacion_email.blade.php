@extends('app')
@section('content')
  <div class="row">
      <div class=" col-md-6 col-md-offset-3"  >
        <div class="panel panel-default panel-success">
          <div class="panel-heading"> Correo Electrónico confirmado</div>
          <div class="panel-body">

            <div class="row">
              <div class="col-md-8 col-md-offset-2">
                <p class="text-info">Se envió su acceso a </p>
                <a href="" class="btn btn-success pull-right">Iniciar sesión</a>
              </div>
            </div>

            </div>
          </div>
        </div>
      </div>
  </div>
@endsection
